import { BehaviorSubject, Subscription } from 'rxjs';
import {
  Component,
  ViewEncapsulation,
  HostListener,
  OnChanges,
  OnDestroy,
  OnInit,
} from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Menu, NavService } from '../../services/nav.service';
import { LayoutService } from '../../services/layout.service';
import { CookiesServicesService } from '../../services/cookies-services.service';
import { ApiService } from '../../services/api.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class SidebarComponent implements OnInit {
  public changePassword = {
    id: 7,
    canEdit: true,
    path: '/setting/change_password',
    title: 'Change Password',
    type: 'link',
  };
  public settingObject = {
    id: 10,
    canEdit: true,
    title: 'Settings',
    icon: 'settings',
    type: 'sub',
    badgeType: 'success',
    badgeValue: '6',
    active: false,
    children: [
      {
        id: 7,
        canEdit: true,
        path: '/setting/change_password',
        title: 'Change Password',
        type: 'link',
      },
    ],
  };
  public WLuserName: any;
  public iconSidebar;
  public menuItems: Menu[];
  public url: any;
  public fileurl: any;

  // For Horizontal Menu
  public margin: any = 0;
  public width: any = window.innerWidth;
  public leftArrowNone: boolean = true;
  public rightArrowNone: boolean = false;
  public userDetails: any = {};
  public permissions: any[] = [];
  public displayMenuItems = new BehaviorSubject<Menu[]>([]);

  constructor(
    private cookiesServicesService: CookiesServicesService,
    private router: Router,
    public navServices: NavService,
    public layout: LayoutService,
    private apiService: ApiService,
    private authService: AuthService
  ) {}

  async ngOnInit() {
    this.userDetails = JSON.parse(
      this.cookiesServicesService.getCookie('userDetails') as string
    );
    this.WLuserName = this.userDetails?.username;
    this.initializeSidebar();
  }

  async handleMenuItems() {
    this.navServices.items.subscribe((menuItemsData) => {
      this.menuItems = menuItemsData;
      this.router.events.subscribe((event) => {
        if (event instanceof NavigationEnd) {
          this.menuItems.filter((items) => {
            if (items.path === event.url) {
              this.setNavActive(items);
            }
            if (!items.children) {
              return false;
            }
            items.children.filter((subItems) => {
              if (subItems.path === event.url) {
                this.setNavActive(subItems);
              }
              if (!subItems.children) {
                return false;
              }
              subItems.children.filter((subSubItems) => {
                if (subSubItems.path === event.url) {
                  this.setNavActive(subSubItems);
                }
              });
            });
          });
        }
      });
    });
  }

  async fetchRolePermission() {
    try {
      console.log('api role');
      const response: any = await this.apiService
        .getRolePermissions(this.userDetails?.role?.id)
        .toPromise(); // Use toPromise()

      this.permissions = [...response?.data];
    } catch (error) {
      console.log({ error });
    }
  }

  // async handleData() {
  //   if (this?.userDetails?.role?.name !== 'superadmin') {
  //     let menuItems = this.menuItems;
  //     let permissions = this.permissions;

  //     // To store matching modules and submodules
  //     let matchingItems = [];

  //     for (let module of menuItems) {
  //       // Check if the module matches any permission
  //       let moduleMatch = permissions.find(
  //         (permission) => permission.module_id === module.id
  //       );

  //       Object.assign(module, {
  //         ...module,
  //         canEdit: moduleMatch?.can_edit,
  //       });
  //       if (moduleMatch) {
  //         // Check for submodule matches
  //         if (module.children?.length) {
  //           module.children = module.children.filter((child) => {
  //             const findChildren = permissions.find(
  //               (permission) =>
  //                 permission.module_id === module.id &&
  //                 permission.submodule_id === child.id
  //             );

  //             Object.assign(child, {
  //               ...child,
  //               canEdit: findChildren?.can_edit,
  //             });

  //             return findChildren;
  //           });
  //         }
  //         matchingItems.push(module);
  //       }
  //     }
  //     this.displayMenuItems.next([...matchingItems]); // Set filtered menu items
  //     // console.log('Filtered Menu Items:', this.displayMenuItems);
  //     // this.router.navigate([matchingItems[0]?.path]);
  //     // this.authService.setData({ ...this.menuItems[0] });
  //     // this.navigateWithData(this.menuItems?.find((x) => x?.active || x));
  //   } else {
  //     // this.displayMenuItems = this.menuItems; // Set filtered menu items
  //     this.displayMenuItems.next([...this.menuItems]); // Set filtered menu items

  //     let activeObject = this.authService.getData();
  //     let findActiveInMenu = this.menuItems?.find(
  //       (x) => x?.id == activeObject?.id
  //     );
  //     console.log({ activeObject });
  //     this.navigateWithData(findActiveInMenu || this.menuItems[0]);

  //     // this.router.navigate([this.menuItems[0]?.path]);
  //     // this.authService.setData({ ...this.menuItems[0] });
  //   }
  //   // this.router.navigate([this.displayMenuItems[0]?.path]);
  //   // this.authService.setData({ ...this.displayMenuItems[0] });
  // }

  async handleData() {
    const cachedMenuItems = localStorage.getItem('sidebarMenuItems');
    if (cachedMenuItems) {
      // Use cached data
      this.displayMenuItems.next(JSON.parse(cachedMenuItems));
      console.log(this.displayMenuItems, 'Using cached sidebar items.');
      return;
    }

    // Process data if not cached
    if (this?.userDetails?.role?.name !== 'superadmin') {
      let matchingItems = [];
      for (let module of this.menuItems) {
        // Check module permissions
        let moduleMatch = this.permissions.find(
          (permission) => permission.module_id === module.id
        );

        Object.assign(module, {
          ...module,
          canEdit: moduleMatch?.can_edit,
        });

        if (moduleMatch) {
          // Check submodules
          if (module.children?.length) {
            module.children = module.children.filter((child) => {
              const findChildren = this.permissions.find(
                (permission) =>
                  permission.module_id === module.id &&
                  permission.submodule_id === child.id
              );

              Object.assign(child, {
                ...child,
                canEdit: findChildren?.can_edit,
              });

              return findChildren;
            });
          }
          matchingItems.push(module);
        }
      }
      this.displayMenuItems.next([...matchingItems]);

      const settingsItem = this.displayMenuItems.value?.find(
        (item) => item?.title?.toLowerCase() === 'settings'
      );

      console.log(settingsItem);

      if (settingsItem) {
        settingsItem?.children?.push(this.changePassword);
        // this.handleNavigation();
        localStorage.setItem('sidebarMenuItems', JSON.stringify(matchingItems));
      } else {
        let settingArray = [];
        settingArray.push(this.settingObject);

        const updatedMenuItems = [...matchingItems, ...settingArray]; // Combine both arrays

        this.displayMenuItems.next(updatedMenuItems);

        // this.handleNavigation();
        localStorage.setItem(
          'sidebarMenuItems',
          JSON.stringify(updatedMenuItems)
        );
      }

      // this.handleNavigation();
      // localStorage.setItem('sidebarMenuItems', JSON.stringify(matchingItems));
    } else {
      // For superadmin, use all menu items
      this.displayMenuItems.next([...this.menuItems]);
      const settingsItem = this.displayMenuItems.value.find(
        (item) => item.title === 'Settings'
      );

      settingsItem?.children?.push(this.changePassword);
      // this.handleNavigation();
      localStorage.setItem('sidebarMenuItems', JSON.stringify(this.menuItems));
    }

    this.handleNavigation();

    console.log('Sidebar items set and cached.');
  }
  settingModule(settingModule: any) {
    throw new Error('Method not implemented.');
  }

  async initializeSidebar() {
    const cachedMenuItems = localStorage.getItem('sidebarMenuItems');
    console.log({ cachedMenuItems });
    if (!cachedMenuItems) {
      console.log('Fetching menu items and permissions for the first time.');
      await this.navServices.fetchMenuItems();
      await this.handleMenuItems();
      await this.fetchRolePermission();
      await this.handleData();
    } else {
      console.log('Using cached menu items.');
      this.handleData();
    }
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.width = event.target.innerWidth - 500;
  }

  sidebarToggle() {
    this.navServices.collapseSidebar = !this.navServices.collapseSidebar;
  }

  // Active Nave state
  setNavActive(item) {
    this.menuItems.filter((menuItem) => {
      if (menuItem !== item) {
        menuItem.active = false;
      }
      if (menuItem.children && menuItem.children.includes(item)) {
        menuItem.active = true;
      }
      if (menuItem.children) {
        menuItem.children.filter((submenuItems) => {
          if (submenuItems.children && submenuItems.children.includes(item)) {
            menuItem.active = true;
            submenuItems.active = true;
          }
        });
      }
    });
  }

  handleClick(item: any): void {
    console.log('Clicked Item:', item);
  }

  // Click Toggle menu
  toggletNavActive(item) {
    console.log({ item });
    if (!item.active) {
      this.displayMenuItems?.value?.forEach((a) => {
        if (this.displayMenuItems?.value?.includes(item)) {
          a.active = false;
        }
        if (!a.children) {
          return false;
        }
        a.children.forEach((b) => {
          if (a?.children?.includes(item)) {
            b.active = false;
          }
        });
      });
    }
    item.active = !item.active;
  }

  // For Horizontal Menu
  scrollToLeft() {
    if (this.margin >= -this.width) {
      this.margin = 0;
      this.leftArrowNone = true;
      this.rightArrowNone = false;
    } else {
      this.margin += this.width;
      this.rightArrowNone = false;
    }
  }

  scrollToRight() {
    if (this.margin <= -3051) {
      this.margin = -3464;
      this.leftArrowNone = false;
      this.rightArrowNone = true;
    } else {
      this.margin += -this.width;
      this.leftArrowNone = false;
    }
  }

  navigateWithData(childrenItem: any) {
    this.authService.setData({ ...childrenItem });
    this.router.navigate([childrenItem?.path]);
  }

  handleNavigation() {
    let activeObject = this.authService.getData();
    let findActiveInMenu = this.displayMenuItems?.value?.find(
      (x) => x?.id == activeObject?.id
    );
    console.log({ activeObject });
    this.navigateWithData(
      findActiveInMenu ||
        (this.displayMenuItems?.value[0] &&
          this.displayMenuItems?.value[0]?.children?.length)
        ? this.displayMenuItems?.value[0]?.children[0]
        : this.displayMenuItems?.value[0]
    );
  }
}
