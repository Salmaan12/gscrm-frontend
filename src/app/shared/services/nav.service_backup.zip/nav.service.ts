import { Injectable, OnDestroy, OnInit } from '@angular/core';
import { Subject, BehaviorSubject, fromEvent, forkJoin } from 'rxjs'; // Add forkJoin here
import { takeUntil, debounceTime, map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CookiesServicesService } from './cookies-services.service';
import { ApiService } from './api.service';
import { environment } from '../../../environments/environment';

// Menu
export interface Menu {
  id?: number;
  headTitle1?: string;
  headTitle2?: string;
  path?: string;
  title?: string;
  icon?: string;
  type?: string;
  badgeType?: string;
  badgeValue?: string;
  active?: boolean;
  bookmark?: boolean;
  children?: Menu[];
}

@Injectable({
  providedIn: 'root',
})
export class NavService implements OnDestroy {
  public userDetails = JSON.parse(
    this.cookiesServicesService.getCookie('userDetails')
  );
  private unsubscriber: Subject<any> = new Subject();
  public screenWidth: BehaviorSubject<number> = new BehaviorSubject(
    window.innerWidth
  );
  public items = new BehaviorSubject<Menu[]>([]); // Dynamic menu items

  // Search Box
  public search: boolean = false;

  // Language
  public language: boolean = false;

  // Mega Menu
  public megaMenu: boolean = false;
  public levelMenu: boolean = false;
  public megaMenuColapse: boolean = window.innerWidth < 1199 ? true : false;

  // For Horizontal Layout Mobile
  public horizontal: boolean = window.innerWidth < 991 ? false : true;

  // Collapse Sidebar
  public collapseSidebar: boolean = window.innerWidth < 991 ? true : false;

  // Full screen
  public fullScreen: boolean = false;
  public permissions: any[] = [];
  constructor(
    private cookiesServicesService: CookiesServicesService,
    private _apiService: ApiService,
    private router: Router,
    private http: HttpClient
  ) {
    this.setScreenWidth(window.innerWidth);
    fromEvent(window, 'resize')
      .pipe(debounceTime(1000), takeUntil(this.unsubscriber))
      .subscribe((evt: any) => {
        this.setScreenWidth(evt.target.innerWidth);
        if (evt.target.innerWidth < 991) {
          this.collapseSidebar = true;
          this.megaMenu = false;
          this.levelMenu = false;
        }
        if (evt.target.innerWidth < 1199) {
          this.megaMenuColapse = true;
        }
      });
    if (window.innerWidth < 991) {
      // Detect Route change sidebar close
      this.router.events.subscribe((event) => {
        this.collapseSidebar = true;
        this.megaMenu = false;
        this.levelMenu = false;
      });
    }
    // this.fetchMenuItemsAndPermissions();
    // this.fetchRolePermissions();
    // console.log('iiiiiiiiiiiiiii');
    // this.fetchMenuItems();
    // const permi = this.fetchRolePermission();
    // this.permissions = permi
    // console.log({ permi });
    // this.handleData();
    // this.fetchPermissionsFromApi();
  }

  ngOnDestroy() {
    this.unsubscriber.next();
    this.unsubscriber.complete();
  }

  private setScreenWidth(width: number): void {
    this.screenWidth.next(width);
  }

  // private fetchMenuItemsAndPermissions() {

  // if (condition) {
  //   this.http.get<Menu[]>('assets/i18n/menu-items.json')
  //   .pipe() // Menu JSON

  // } else {

  // }
  // Fetch the menu items and permissions simultaneously
  // const userDetails = JSON.parse(
  //   this.cookiesServicesService.getCookie('userDetails')
  // );

  // forkJoin([
  //   this.http.get<Menu[]>('assets/i18n/menu-items.json'), // Menu JSON
  //   this._apiService.getRolePermissions(userDetails?.role?.id), // API response
  // ])
  //   .pipe(
  //     map(([menuItems, permissions]) =>
  //       this.filterMenuItems(menuItems, permissions.data)
  //     ) // Filter data
  //   )
  //   .subscribe(
  //     (filteredMenuItems) => {
  //       this.items.next(filteredMenuItems);
  //       console.log('Filtered Menu Items:', filteredMenuItems);
  //     },
  //     (error) => console.error('Error loading data:', error)
  //   );
  // }

  // private filterMenuItems(menuItems: Menu[], permissions: any[]): Menu[] {
  //   return menuItems
  //     .map((menu) => {
  //       // Match the module
  //       const matchingPermission = permissions.find(
  //         (perm) => perm.module_id === menu.id && perm.submodule_id === null
  //       );

  //       // Filter submodules if they exist
  //       const filteredChildren = menu.children?.filter((child) =>
  //         permissions.some(
  //           (perm) =>
  //             perm.module_id === menu.id && perm.submodule_id === child.id
  //         )
  //       );

  //       // Return the filtered menu if the module or its children match
  //       if (
  //         matchingPermission ||
  //         (filteredChildren && filteredChildren.length)
  //       ) {
  //         return {
  //           ...menu,
  //           children: filteredChildren || [], // Set filtered children
  //         };
  //       }
  //       return null; // Exclude this menu if no matches
  //     })
  //     .filter((menu) => menu !== null); // Remove null entries
  // }

  // private fetchPermissionsFromApi() {
  //   const userDetails = JSON.parse(
  //     this.cookiesServicesService.getCookie('userDetails')
  //   );
  //   const roleId = userDetails?.role?.id;

  //   this._apiService
  //     .getRolePermissions(roleId)
  //     .pipe(takeUntil(this.unsubscriber))
  //     .subscribe(
  //       (menuItems) => {
  //         this.items.next(menuItems);
  //         console.log(menuItems);
  //       },
  //       (error) => console.error('Error loading role permissions:', error)
  //     );
  // }

  // fetchRolePermissions() {
  //   let userDetails = JSON.parse(
  //     this.cookiesServicesService.getCookie('userDetails')
  //   );
  //   console.log(userDetails);
  //   const roleId = userDetails?.role?.id;

  //   this._apiService.getRolePermissions(2).subscribe((res: any) => {});
  // }

  async fetchMenuItems() {
    console.log('fetch menu');
    try {
      const userType = environment.wlType; // Get user type from cookie
      this.http
        .get<Menu[]>('assets/i18n/menu-items.json')
        .pipe(takeUntil(this.unsubscriber))
        .subscribe(
          (menuItemsData) => {
            // Modify the menu items based on the user type
            if (userType === 'agentPortal') {
              menuItemsData = menuItemsData.filter(
                (menuItem) => menuItem.title !== 'Customer'
              );
            }

            this.items.next(menuItemsData); // Update the BehaviorSubject
          },
          (error) => console.error('Error loading menu items:', error)
        );
    } catch (error) {
      console.log({ error });
    }
  }

  // async fetchRolePermission() {
  //   try {
  //     this._apiService
  //       .getRolePermissions(this.userDetails?.role?.id)
  //       .subscribe((res) => {
  //         this.permissions = [...res?.data];
  //         // console.log(res.data);
  //         return res.data;
  //       });
  //   } catch (error) {
  //     console.log({ error });
  //   }
  // }

  // async handleData() {
  //   if (this?.userDetails?.role?.name !== 'superadmin') {
  //     let array1 = this.items;
  //     let array2 = this.permissions;
  //     console.log({ array1, array2 });
  //   }
  // }

  // MENUITEMS: Menu[]
  // =
  // [
  // {
  // 	headTitle1: 'Sample', headTitle2: 'Ready Sample Page.',
  // },
  //   {
  //     path: '/dashboard/default',
  //     title: 'Dashboard',
  //     icon: 'menu',
  //     type: 'link',
  //     bookmark: true,
  //   },
  //   {
  //     title: 'Plan',
  //     icon: 'home',
  //     type: 'sub',
  //     bookmark: true,
  //     badgeType: 'success',
  //     badgeValue: '1',
  //     active: true,
  //     children: [
  //       {
  //         path: '/plan/add_plan',
  //         title: 'Change eSIM Plans Price',
  //         type: 'link',
  //       },
  //       // { path: '/plan/assign_plan', title: 'Available eSim Plans', type: 'link' }
  //     ],
  //   },
  //   {
  //     path: '/coupon/create_coupons',
  //     title: 'Coupons',
  //     icon: 'tag',
  //     type: 'link',
  //     bookmark: true,
  //   },
  //   {
  //     path: '/purchase-esim/purchase',
  //     title: 'Purchase eSIM',
  //     icon: 'shopping-cart',
  //     type: 'link',
  //     bookmark: true,
  //   },
  //   {
  //     title: 'Recharge eSIM',
  //     path: '/recharge-esim/recharge',
  //     icon: 'sunset',
  //     type: 'link',
  //     bookmark: true,
  //   },
  //   {
  //     title: 'Activate eSIM',
  //     path: '/activate-esim/activate',
  //     icon: 'sunrise',
  //     type: 'link',
  //     bookmark: true,
  //   },
  //   {
  //     title: 'Orders',
  //     icon: 'shopping-cart',
  //     type: 'sub',
  //     bookmark: true,
  //     badgeType: 'success',
  //     badgeValue: '2',
  //     active: true,
  //     children: [
  //       { path: '/order/eSim', title: 'eSIM', type: 'link' },
  //       { path: '/order/topup', title: 'Topup', type: 'link' },
  //       { path: '/order/refund', title: 'Refund Logs', type: 'link' },
  //       // { path: '/order/purchase-esim', title: 'Purchase Esim', type: 'link' },
  //     ],
  //   },
  //   {
  //     title: 'Customer',
  //     icon: 'user',
  //     type: 'sub',
  //     bookmark: true,

  //     active: true,
  //     children: [
  //       { path: '/customer/customer-list', title: 'List', type: 'link' },
  //       {
  //         path: '/customer/refund-request',
  //         title: 'Refund request',
  //         type: 'link',
  //       },
  //     ],
  //   },
  //   // { path: '/role-permission/add_role', title: 'Role Permission', icon: 'home', type: 'link', bookmark: true },
  //   {
  //     title: 'Reports',
  //     path: 'reports',
  //     icon: 'book',
  //     type: 'sub',
  //     bookmark: true,
  //     active: false,
  //     children: [
  //       { path: '/report/accounting', title: 'Accounting', type: 'link' },
  //     ],
  //   },
  //   {
  //     title: 'Settings',
  //     icon: 'settings',
  //     type: 'sub',
  //     badgeType: 'success',
  //     badgeValue: '6',
  //     active: true,
  //     children: [
  //       {
  //         path: '/setting/wallet-history',
  //         title: 'Wallet History',
  //         type: 'link',
  //       },
  //       {
  //         path: '/contact/user',
  //         title: 'Contact',
  //         icon: 'home',
  //         type: 'link',
  //         bookmark: true,
  //       },
  //       {
  //         path: '/contact/partner',
  //         title: 'Affiliate',
  //         icon: 'home',
  //         type: 'link',
  //         bookmark: true,
  //       },
  //       // { path: '/contact/reseller', title: 'Reseller', icon: 'home', type: 'link', bookmark: true },
  //       { path: '/faq/add_faq', title: 'FAQ', type: 'link' },
  //       { path: '/setting/emails', title: 'Email', type: 'link' },
  //       {
  //         path: '/setting/mobile_device',
  //         title: 'Add Mobile Device',
  //         type: 'link',
  //       },
  //       {
  //         path: '/setting/change_password',
  //         title: 'Change Password',
  //         type: 'link',
  //       },
  //     ],
  //   },
  // ];

  MEGAMENUITEMS: Menu[] = [
    {
      title: 'Error Pages',
      type: 'sub',
      active: true,
      children: [
        {
          path: 'javascript:void(0);',
          title: 'Error Page 400',
          type: 'extLink',
        },
        {
          path: 'javascript:void(0);',
          title: 'Error Page 401',
          type: 'extLink',
        },
        {
          path: 'javascript:void(0);',
          title: 'Error Page 403',
          type: 'extLink',
        },
        {
          path: 'javascript:void(0);',
          title: 'Error Page 404',
          type: 'extLink',
        },
        {
          path: 'javascript:void(0);',
          title: 'Error Page 500',
          type: 'extLink',
        },
        {
          path: 'javascript:void(0);',
          title: 'Error Page 503',
          type: 'extLink',
        },
      ],
    },
    {
      title: 'Authentication',
      type: 'sub',
      active: false,
      children: [
        { path: 'javascript:void(0);', title: 'Login Simple', type: 'extLink' },
        {
          path: 'javascript:void(0);',
          title: 'Login BG Image',
          type: 'extLink',
        },
        {
          path: 'javascript:void(0);',
          title: 'Login BG Video',
          type: 'extLink',
        },
        {
          path: 'javascript:void(0);',
          title: 'Simple Register',
          type: 'extLink',
        },
        {
          path: 'javascript:void(0);',
          title: 'Register BG Image',
          type: 'extLink',
        },
        {
          path: 'javascript:void(0);',
          title: 'Register BG Video',
          type: 'extLink',
        },
      ],
    },
    {
      title: 'Usefull Pages',
      type: 'sub',
      active: false,
      children: [
        { path: 'javascript:void(0);', title: 'Search Pages', type: 'extLink' },
        { path: 'javascript:void(0);', title: 'Unlock User', type: 'extLink' },
        {
          path: 'javascript:void(0);',
          title: 'Forgot Password',
          type: 'extLink',
        },
        {
          path: 'javascript:void(0);',
          title: 'Reset Password',
          type: 'extLink',
        },
        { path: 'javascript:void(0);', title: 'Maintenance', type: 'extLink' },
      ],
    },
    {
      title: 'Email templates',
      type: 'sub',
      active: false,
      children: [
        {
          path: 'http://admin.pixelstrap.com/cuba/theme/basic-template.html',
          title: 'Basic Email',
          type: 'extTabLink',
        },
        {
          path: 'http://admin.pixelstrap.com/cuba/theme/email-header.html',
          title: 'Basic With Header',
          type: 'extTabLink',
        },
        {
          path: 'http://admin.pixelstrap.com/cuba/theme/template-email.html',
          title: 'Ecomerce Template',
          type: 'extTabLink',
        },
        {
          path: 'http://admin.pixelstrap.com/cuba/theme/template-email-2.html',
          title: 'Email Template 2',
          type: 'extTabLink',
        },
        {
          path: 'http://admin.pixelstrap.com/cuba/theme/ecommerce-templates.html',
          title: 'Ecommerce Email',
          type: 'extTabLink',
        },
        {
          path: 'http://admin.pixelstrap.com/cuba/theme/email-order-success.html',
          title: 'Order Success',
          type: 'extTabLink',
        },
      ],
    },
    {
      title: 'Coming Soon',
      type: 'sub',
      active: false,
      children: [
        {
          path: 'javascript:void(0);',
          title: 'Coming Simple',
          type: 'extLink',
        },
        {
          path: 'javascript:void(0);',
          title: 'Coming BG Image',
          type: 'extLink',
        },
        {
          path: 'javascript:void(0);',
          title: 'Coming BG Video',
          type: 'extLink',
        },
      ],
    },
  ];

  LEVELMENUITEMS: Menu[] = [
    {
      path: 'javascript:void(0);',
      title: 'File Manager',
      icon: 'git-pull-request',
      type: 'extLink',
    },
    {
      title: 'Users',
      icon: 'users',
      type: 'sub',
      active: false,
      children: [
        {
          path: 'javascript:void(0);',
          title: 'All Users',
          icon: 'users',
          type: 'extLink',
        },
        {
          path: 'javascript:void(0);',
          title: 'User Profile',
          icon: 'users',
          type: 'extLink',
        },
        {
          path: 'javascript:void(0);',
          title: 'Edit Profile',
          icon: 'users',
          type: 'extLink',
        },
      ],
    },
    {
      path: 'javascript:void(0);',
      title: 'Bookmarks',
      icon: 'heart',
      type: 'extLink',
    },
    {
      path: 'javascript:void(0);',
      title: 'Calender',
      icon: 'calendar',
      type: 'extLink',
    },
    {
      path: 'javascript:void(0);',
      title: 'Social App',
      icon: 'zap',
      type: 'extLink',
    },
  ];

  // Array
  // items = new BehaviorSubject<Menu[]>(this.MENUITEMS);
  megaItems = new BehaviorSubject<Menu[]>(this.MEGAMENUITEMS);
  levelmenuitems = new BehaviorSubject<Menu[]>(this.LEVELMENUITEMS);
}
